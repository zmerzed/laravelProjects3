<?php

return [
    'ja' => 'Japanese',
    'en' => 'English'
];
