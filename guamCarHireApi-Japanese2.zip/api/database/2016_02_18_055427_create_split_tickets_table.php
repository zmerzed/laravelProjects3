<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSplitTicketsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::drop('split_tickets');
        Schema::create('split_tickets', function (Blueprint $table) {
            $table->increments('id');
            $table->string('receive_key');
            $table->integer('user_ticket_id');
            $table->integer('received_user_id');
            $table->datetime('received_date');
            $table->integer('adult_num');
            $table->integer('child_num');
            $table->boolean('valid')->default(true);
            $table->dateTime('created_at');
            $table->dateTime('updated_at');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('split_tickets');
    }
}
