<html>
    <head></head>
    <body>
        <div class="container">
            <div class="content">
	            <div><label>Name : </label></br>{{ $name }}</div>
	            </br>
	            <div><label>Email : </label></br>{{ $email }}</div>
	            </br>
	            <div><label>Message : </label></br>{{ $msg }}</div>   	
            </div>    	
        </div>
    </body>
</html>
