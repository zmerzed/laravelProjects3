@extends ('layouts.plane')
@section ('body')
<style type="text/css">
.seperator{width: 95%;font-size: 1px;color: rgba(0, 0, 0, 0); line-height: 1px;background-color: grey;margin-top: 5px;margin-bottom: 5px;}
</style>
<div class="container">
{{ trans('validation.custom.message.status') }}
	<div class="row">
		<strong>Login</strong>
		{!! Form::model(null, array('route' => array('user.login', ''), 'class'=>'form-horizontal','method'=>'POST')) !!}  
		        <!-- name -->
		        <div class="form-group">
		        	{!! Form::label('name', 'Name', $attributes = array('class'=>'col-md-4 control-label')) !!}
		        	<div class="col-md-6">
		        		{!! Form::email('email') !!}
		        	</div> 
				</div>
		        <!-- email -->
		        <div class="form-group">
			        {!! Form::label('email', 'Email', $attributes = array('class'=>'col-md-4 control-label')) !!}
			        <div class="col-md-6">			
			       		{!! Form::password('password') !!}  
			        </div>    
				</div>
		        {!! Form::submit('Login') !!}	
		{!! Form::close() !!}	
		<div class="seperator">&nbsp;</div>
		<strong>Register - POST(Validating)</strong>
		{!! Form::model(null, array('route' => array('user.regmethod', ''), 'class'=>'form-horizontal','method'=>'POST')) !!}  
				{!! Form::hidden('_regtype', 'Validate') !!}
		        <!-- name -->
		        <div class="form-group">
		        	{!! Form::label('name', 'Name', $attributes = array('class'=>'col-md-4 control-label')) !!}
		        	<div class="col-md-6">
		        		{!! Form::text('name') !!}
		        	</div> 
				</div>
		        <!-- email -->
		        <div class="form-group">
			        {!! Form::label('email', 'Email', $attributes = array('class'=>'col-md-4 control-label')) !!}
			        <div class="col-md-6">			
			       		{!! Form::email('email') !!}  
			        </div>    
				</div>
				<!-- email confirm -->
		        <div class="form-group">
			        {!! Form::label('email_confirm', 'Email Confirm', $attributes = array('class'=>'col-md-4 control-label')) !!}
			        <div class="col-md-6">			
			       		{!! Form::email('email_confirm') !!}  
			        </div>    
				</div>
				<!-- password -->
		        <div class="form-group">
			        {!! Form::label('password', 'Password', $attributes = array('class'=>'col-md-4 control-label')) !!}
			        <div class="col-md-6">			
			       		{!! Form::password('password') !!}  
			        </div>    
				</div>
				<!-- password confirm -->
		        <div class="form-group">
			        {!! Form::label('password_confirm', 'Password Confirm', $attributes = array('class'=>'col-md-4 control-label')) !!}
			        <div class="col-md-6">			
			       		{!! Form::password('password_confirm') !!}  
			        </div>    
				</div>
				
		        {!! Form::submit('Validate Values') !!}
		
		{!! Form::close() !!}	
		<div class="seperator">&nbsp;</div>
		<strong>Register - POST(Saving)</strong>
		{!! Form::model(null, array('route' => array('user.regmethod', ''), 'class'=>'form-horizontal','method'=>'POST')) !!}  
				{!! Form::hidden('_regtype', 'Save') !!}
		        <!-- name -->
		        <div class="form-group">
		        	{!! Form::label('name', 'Name', $attributes = array('class'=>'col-md-4 control-label')) !!}
		        	<div class="col-md-6">
		        		{!! Form::text('name') !!}
		        	</div> 
				</div>
		        <!-- email -->
		        <div class="form-group">
			        {!! Form::label('email', 'Email', $attributes = array('class'=>'col-md-4 control-label')) !!}
			        <div class="col-md-6">			
			       		{!! Form::email('email') !!}  
			        </div>    
				</div>
				<!-- email confirm -->
		        <div class="form-group">
			        {!! Form::label('email_confirm', 'Email Confirm', $attributes = array('class'=>'col-md-4 control-label')) !!}
			        <div class="col-md-6">			
			       		{!! Form::email('email_confirm') !!}  
			        </div>    
				</div>
				<!-- password -->
		        <div class="form-group">
			        {!! Form::label('password', 'Password', $attributes = array('class'=>'col-md-4 control-label')) !!}
			        <div class="col-md-6">			
			       		{!! Form::password('password') !!}  
			        </div>    
				</div>
				<!-- password confirm -->
		        <div class="form-group">
			        {!! Form::label('password_confirm', 'Password Confirm', $attributes = array('class'=>'col-md-4 control-label')) !!}
			        <div class="col-md-6">			
			       		{!! Form::password('password_confirm') !!}  
			        </div>    
				</div>
		        {!! Form::submit('Create New User') !!}
		
		{!! Form::close() !!}	
	</div>
	<div class="seperator">&nbsp;</div>
	<div class="row">		
		<strong>Edit - PUT(Validating)</strong>	
		{!! Form::model($user, array('route' => array('user.editmethod', $user->id), 'class'=>'form-horizontal','method'=>'PUT')) !!}  
				{!! Form::hidden('_edittype', 'Validate') !!}
		        <!-- name -->
		        <div class="form-group">
		        	{!! Form::label('name', 'Name', $attributes = array('class'=>'col-md-4 control-label')) !!}
		        	<div class="col-md-6">
		        		{!! Form::text('name') !!}
		        	</div> 
				</div>
		        <!-- email -->
		        <div class="form-group">
			        {!! Form::label('email', 'Email', $attributes = array('class'=>'col-md-4 control-label')) !!}
			        <div class="col-md-6">			
			       		{!! Form::email('email') !!}  
			        </div>    
				</div>
				<!-- email confirm -->
		        <div class="form-group">
			        {!! Form::label('email_confirm', 'Email Confirm', $attributes = array('class'=>'col-md-4 control-label')) !!}
			        <div class="col-md-6">			
			       		{!! Form::email('email_confirm') !!}  
			        </div>    
				</div>
				<!-- password -->
		        <div class="form-group">
			        {!! Form::label('password', 'Password', $attributes = array('class'=>'col-md-4 control-label')) !!}
			        <div class="col-md-6">			
			       		{!! Form::password('password') !!}  
			        </div>    
				</div>
				<!-- password confirm -->
		        <div class="form-group">
			        {!! Form::label('password_confirm', 'Password Confirm', $attributes = array('class'=>'col-md-4 control-label')) !!}
			        <div class="col-md-6">			
			       		{!! Form::password('password_confirm') !!}  
			        </div>    
				</div>
		        {!! Form::submit('Validate Values') !!}
		
		{!! Form::close() !!}	
		<div class="seperator">&nbsp;</div>
		<strong>Edit - PUT(Updating)</strong>	
		{!! Form::model($user, array('route' => array('user.editmethod', $user->id), 'class'=>'form-horizontal','method'=>'PUT')) !!}  
				{!! Form::hidden('_edittype', 'Save') !!}
		        <!-- name -->
		        <div class="form-group">
		        	{!! Form::label('name', 'Name', $attributes = array('class'=>'col-md-4 control-label')) !!}
		        	<div class="col-md-6">
		        		{!! Form::text('name') !!}
		        	</div> 
				</div>
		        <!-- email -->
		        <div class="form-group">
			        {!! Form::label('email', 'Email', $attributes = array('class'=>'col-md-4 control-label')) !!}
			        <div class="col-md-6">			
			       		{!! Form::email('email') !!}  
			        </div>    
				</div>
				<!-- email confirm -->
		        <div class="form-group">
			        {!! Form::label('email_confirm', 'Email Confirm', $attributes = array('class'=>'col-md-4 control-label')) !!}
			        <div class="col-md-6">			
			       		{!! Form::email('email_confirm') !!}  
			        </div>    
				</div>
				<!-- password -->
		        <div class="form-group">
			        {!! Form::label('password', 'Password', $attributes = array('class'=>'col-md-4 control-label')) !!}
			        <div class="col-md-6">			
			       		{!! Form::password('password') !!}  
			        </div>    
				</div>
				<!-- password confirm -->
		        <div class="form-group">
			        {!! Form::label('password_confirm', 'Password Confirm', $attributes = array('class'=>'col-md-4 control-label')) !!}
			        <div class="col-md-6">			
			       		{!! Form::password('password_confirm') !!}  
			        </div>    
				</div>
		        {!! Form::submit('Update User Info') !!}
		
		{!! Form::close() !!}
	</div>
</div>
@stop