Hello {{$username}},

You have requested a new password. Please click the following link to activate 
<br>
New Password: {{$password}}
<br>
Activation link:
<br>
{{$link}}