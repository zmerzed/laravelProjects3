@extends ('layouts.plane')
@section ('body')
<style type="text/css">
.seperator{width: 95%;font-size: 1px;color: rgba(0, 0, 0, 0); line-height: 1px;background-color: grey;margin-top: 5px;margin-bottom: 5px;}
</style>
<div class="container">

	<div class="row">	
		<strong>Contact Form - Validate</strong>
		{!! Form::model(null, array('route' => array('contact.validation', ''), 'class'=>'form-horizontal','method'=>'POST')) !!}  
		        <!-- name -->
		        <div class="form-group">
		        	{!! Form::label('name', 'Name', $attributes = array('class'=>'col-md-4 control-label')) !!}
		        	<div class="col-md-6">
		        		{!! Form::text('name') !!}
		        	</div> 
				</div>
		        <!-- email -->
		        <div class="form-group">
			        {!! Form::label('email', 'Email', $attributes = array('class'=>'col-md-4 control-label')) !!}
			        <div class="col-md-6">			
			       		{!! Form::email('email') !!}  
			        </div>    
				</div>
				<!-- message -->
		        <div class="form-group">
			        {!! Form::label('message', 'Message', $attributes = array('class'=>'col-md-4 control-label')) !!}
			        <div class="col-md-6">			
			       		{!! Form::textarea('message', null, ['size' => '30x5']) !!}  
			        </div>    
				</div>
		        {!! Form::submit('Send') !!}	
		{!! Form::close() !!}	
		<div class="seperator">&nbsp;</div>
		<strong>Contact Form - Send Message</strong>
		{!! Form::model(null, array('route' => array('contact.messaging', ''), 'class'=>'form-horizontal','method'=>'POST')) !!}  
		        <!-- name -->
		        <div class="form-group">
		        	{!! Form::label('name', 'Name', $attributes = array('class'=>'col-md-4 control-label')) !!}
		        	<div class="col-md-6">
		        		{!! Form::text('name') !!}
		        	</div> 
				</div>
		        <!-- email -->
		        <div class="form-group">
			        {!! Form::label('email', 'Email', $attributes = array('class'=>'col-md-4 control-label')) !!}
			        <div class="col-md-6">			
			       		{!! Form::email('email') !!}  
			        </div>    
				</div>
				<!-- message -->
		        <div class="form-group">
			        {!! Form::label('message', 'Message', $attributes = array('class'=>'col-md-4 control-label')) !!}
			        <div class="col-md-6">			
			       		{!! Form::textarea('message', null, ['size' => '30x5']) !!}  
			        </div>    
				</div>
		        {!! Form::submit('Send') !!}	
		{!! Form::close() !!}
	</div>
</div>
@stop