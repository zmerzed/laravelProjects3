<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Custom Language Lines
    |--------------------------------------------------------------------------
    | custom API languaege texts.
    | 
    | 
    | 
    |
    */

    'error_saving'              => 'Error in saving.',
    'fail_to'                   => 'It failed to :name .',               
    'record_not_registered'     => 'The :name is not registered.',
    'record_not_found'          => 'There is no :name.',
    'error_auth'                => 'Authentication Error',
    'success'                   => 'Success',
    'token_expired'             => 'Token Expired.',
    'error_occured'				=> 'An error occurred',
    
];
