<?php
return [
    'welcome' => 'Welcome to our application',
    'noticket' => 'There is no ticket.',
];
