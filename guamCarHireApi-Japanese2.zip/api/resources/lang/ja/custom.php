<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Custom Language Lines
    |--------------------------------------------------------------------------
    | custom API languaege texts.
    | 
    | 
    | 
    |
    */

    'error_saving'              => 'セーブ中にエラーが発生しました。',
    'fail_to'                   => 'それはに失敗しました。 :name 。', 
    'record_not_registered'     => ':name 登録されていません。',
    'record_not_found'          => '全くありません :name.',
    'error_auth'                => '認証エラー',
    'success'                   => '成功',
    'token_expired'             => '期限切れのトークン。',
];
