<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Ticket extends Model
{
    //
    function getGroupedByType(){
        $tickets = $this->where('valid', '=', true)
            ->get(['id', 'name', 'description', 'adult_price', 'child_price',
                'type','effect_time','effect_days']);
        if(empty($tickets)){
            return false;
        }
        $ticketsGroupedByType = array();
        foreach($tickets->toArray() as $ticket){
            $ticketsGroupedByType[$ticket['type']][] = $ticket; 
        }
        return $ticketsGroupedByType;
    }
    function user_ticket() {
        return $this->hasOne('App\UserTicket');
    }
    
}
