<?php

namespace App;

use DB;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password','email_magazine_subscribed',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
        
    /** 
     * Show a list of all of the application's users.
     *
     * @return Response
     */
    public function getAllUsers()
    {
    	$users = array();
   
    	$usrs = DB::select('select * from users');
        	 
        foreach($usrs AS $k => $v)
    		$users[$v->id] = $v;
    	 
    	return $users;
    }
    
    /**
     * Show a User Detail.
     *
     * @return Response
     */
    public function getUserDetail($id)
    {
    	$user = DB::select('select * from users where id = ?', [$id]);
    	
    	return (isset($user[0]) ? $user[0] : null);  
    } 
       
    public function access_token() {
        return $this->hasOne('App\AccessToken');
    }

    public function user_ticket() {
        return $this->hasOne('App\UserTicket');
    }
    
    /**
     * Generating of tokens.
     *
     * @return Response
     */
    public function generateToken() {
        $api_token      = str_random(75);
        $refresh_token  = str_random(75);
        $date           = date('Y-m-d H:i:s');
        $daynext        = \Carbon\Carbon::parse($date);
        $daynext->addDays(1);
        $expired_date   = $daynext->format('Y-m-d H:i:s');
        
        return array(
            'api_token'     => $api_token,
            'refresh_token' => $refresh_token,
            'expired_date'  => $expired_date
        );
    }

}

