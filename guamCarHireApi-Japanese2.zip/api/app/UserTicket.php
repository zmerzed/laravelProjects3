<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserTicket extends Model
{
    protected $table = 'user_tickets';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id', 'ticket_id', 'adult_num', 'child_num', 'purchase_date','valid'
    ];

    public function ticket() {
    	return $this->belongsTo('App\Ticket','ticket_id');
    }
    public function user() {
    	return $this->belongsTo('App\User','user_id');
    }
    public function split_ticket() {
    	return $this->hasMany('App\SplitTicket');
    }
}
