<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class AccessToken extends Authenticatable
{

    protected $table 	= 'access_tokens';
    protected $fillable	= ['api_token','expired_date','refresh_token_id','user_id','valid','api_client_id'];

    public function user_data() {
    	return $this->belongsTo('App\User','user_id');
    }
    public function refresh_token() {
    	return $this->belongsTo('App\RefreshToken','refresh_token_id');
    }
}
