<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Contact;
use Illuminate\Support\Facades\Validator;

class ContactController extends Controller
{
    /** 
     * @var Contact
     */
    protected $contact;

    /**
     * @param Contact $contact
     */
    public function __construct(Contact $contact)
    {
    	
    	$this->contact = $contact;
        	
    }
        
    /**
     * @type POST
     * @param $request
     * @desc Validate Input
     */
    public function ContactValidate(Request $request){
  	
    	
    	$validator = $this->ValidateFields($request);
    	
    	if ($validator->fails())
    		 
    		return response()->json(array('message' => $this->getErrorMessage(1, array()),
    				'errors' => $validator->messages(),
    				'status' => '422') , 200 );
    	 
    	else
    	
    		return response()->json(array('message' => $this->getNonErrorMessage(-1, array()),
    				'errors' => array(),
    				'status' => '200') , 200 );
    	 
    }
    
    /**
     * @type POST
     * @param $request
     * @desc Sending Message
     */
    public function ContactMessaging(Request $request){
    	
    	try{
    			    	
	    	if(is_array($request))
	    		
	    		$data = $request;
	    	
	    	else	
	    		
	    		$data = $request->input();
	 	
	    	$status = $this->contact->sendmail($data);
	
	    	if($status == 1)
	    		
	    		return response()->json(array('message' => $this->getErrorMessage(1, array()),
	    				'errors' => array(),
	    				'status' => '400') , 200 );
	    	
	    	elseif($status == 2)
	    	
	    		return response()->json(array('message' => $this->getErrorMessage(99, array()),
	    				'errors' => array(),
	    				'status' => '200') , 200 );
	    		
	    	else
	    		
	    		return response()->json(array('message' => $this->getNonErrorMessage(-1, array()),
	    				'errors' => array(),
	    				'status' => '200', 'test' => $data) , 200 );
	    	
    	}catch(Exception $e) {
    		
    		return response()->json(array('message' => $this->getErrorMessage(99, array()),
	    				'errors' => array(),
	    				'status' => '200') , 200 );
    		
    	}
				
    }
   
    /**
     * Get Error Messages
     * @param $i, $param
     * @desc Return Error Messages
     */
    protected function getErrorMessage($i, $param){
    	
	    switch ($i) {
	    	
		    case 0:
		    	
		    	return sprintf(trans('validation.custom.contactvaluserstatus.status'));
		    	
		        break;
		        
		    case 1:
		    	
		        return sprintf('It failed to contact us.');
		        
		        break;

	        case 99:
	        	 
	        	return sprintf('Email not sent! Something wrong check email settings.');
	        
	        	break;
	        	
	        default:
	        	
	        	echo sprintf(trans('validation.custom.contactvaluserstatus.failed'));
	    }
    }

    /**
     * Get Messages
     * @param $i, $param
     * @desc Return Non-Error Messages
     */
    protected function getNonErrorMessage($i, $param){
    	 
    	switch ($i) {
    
    		case 0:
    		  
    			return sprintf('Message Sent!');
    		  
    			break;

    		default:
    
    			return sprintf("Success!");
    	}
    }
    
    /**
     * Validate Fields
     * @param $request
     * @desc Return Non-Error Messages
     */
    protected function ValidateFields($request){
	
	   return Validator::make($request->all(), [
	   		
	    	'name'       => 'required|max:255',
	   		
	    	'email'      => 'required|email|max:255',
	   		
	    	'message'    => 'required|max:1000'
	   		
    	]);
	    	    
    }
 
    public function ContactDefault()
    {  
    	return View('contact');
    }
       
}
