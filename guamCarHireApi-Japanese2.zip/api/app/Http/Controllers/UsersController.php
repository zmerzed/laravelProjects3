<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\Auth\AuthController;
use Illuminate\Pagination\Paginator;
use Illuminate\Contracts\Support\JsonableInterface;
use App\UserTicket;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\User;

class UsersController extends Controller
{
    /** 
     * @var User
     */
    protected $user;
	
    /**
     * @param User $user
     */
    public function __construct(User $user, AuthController $authCtrl)
    {
    	$this->user = $user;
        $this->authCtrl = $authCtrl;
        $this->login_id = (\Auth::check())?$this->authCtrl->guardData('api')['id']:null;
        $this->login_role = (\Auth::check())?$this->authCtrl->guardData('api')['role']:null;
    }


    /**
     * @type GET
     * @param $request,$id
     * @desc Get User Infomation By User Id
     */
    protected function GetUserInformation(Request $request, $id)
    {
    	/*
    	 $user = $this->user->where('valid', true)
    	->where('id', $id)
    	->first();
    	*/
    
    	$user = $this->user->getUserDetail($id);
    
    	if(empty($user))
    			
    		return response()->json(array('message' => $this->getErrorMessage(2, array()), 'errors' => array()), 204);
    
    	return response()->json(array('user' => (!empty($user) ? $user : array())), 200);
    
    }
    
    /**
     * Validate inputed Fields
     * @param $request,$id
     * @desc Validate User input By User Id
     */
    protected function ValidateEditUser(Request $request,$id)
    {
    	 
    	if ($id > 0) {
    			
    		$validator = $this->ValidateFields($request, "1", $id);
    
    		if ($validator->fails())
    			 
    			return response()->json(array('message' => $this->getErrorMessage(3, array()), 'errors' => $validator->messages()) , 200 );
    		 
    		else
    
    			return response()->json(array('message' => $this->getNonErrorMessage(1, array()), 'errors' => array()) , 200 );
    			
    	}else
    
    		return response()->json(array('message' => $this->getErrorMessage(2, array()), 'errors' => array()), 200);
    
    }
    
    /**
     * Edit User Information
     * @param $request,$id
     * @desc Update User input By User Id
     */
    protected function EditUserInformation(Request $request,$id)
    {
    	 
    	if ($id > 0) {
    
    		$fields = array();
    		 
    		foreach($request->input() AS $k => $v)
    
    			if(in_array($k,$this->user->getFillable())){
 			 
    				if($k == 'password' && trim($v) <> ''){
    
    					$v = bcrypt($v);
    
    					$fields[$k] = $v;
    		   
    				}elseif($k <> 'password')
    
    				$fields[$k] = $v;
    			 
    			}
    		 
    		$user = $this->user->where('id', $id)->update($fields);
    
    		if($user > 0){
    
    			$user = $this->user->getUserDetail($id,$this->user->getFillable());
    
    			return response()->json(array('message' => $this->getNonErrorMessage(-1, array()), 'user' => $user) , 200 );
    			 
    		}else
    
    			return response()->json(array('message' => $this->getErrorMessage(0, array()), 'errors' => array()), 200);
    
    	}else
    
    		return response()->json(array('message' => $this->getErrorMessage(2, array()), 'errors' => array()), 200);
    
    }
    
    /**
     * @type PUT, GET
     * @param $request,$id
     * @desc Update User input By User Id, Retreive User Information By User Id
     */
    public function UserInformation(Request $request,$id)
    {
    	 
    	$_edittype = $request->input('_edittype');
    	 
    	if ($request->isMethod('put') && strtolower($_edittype) == strtolower('Validate'))
    
    		return $this->ValidateEditUser($request,$id);
    	 
    	elseif($request->isMethod('put') && strtolower($_edittype) == strtolower('Save'))
    	 
    	return $this->EditUserInformation($request,$id);
    	 
    	else
    
    		return $this->GetUserInformation($request,$id);
    }
    
    /**
     * Validate inputed Fields
     * @param $request
     * @desc Create New User
     */
    protected function ValidateRegistUser(Request $request)
    {
    	 
    	$validator = $this->ValidateFields($request, "0");
    
    	if ($validator->fails())
    		 
    		return response()->json(array('message' => $this->getErrorMessage(5, array()), 'errors' => $validator->messages()) , 200 );
    	 
    	else
    
    		return response()->json(array('message' => $this->getNonErrorMessage(4, array())) , 200 );
    	 
    }
    
    /**
     * Register a User
     * @param $request
     * @desc Create New User
     */
    protected function RegistUser(Request $request)
    {
    	$user = $this->user;
    	 
    	foreach($request->input() AS $k => $v)
    
    		if(in_array($k,$user->getFillable())){
    
    		if($k == 'password')
    
    			$v = bcrypt($v);
    		 
    		$user->{$k} = $v;
    
    	}
    
    	if($user->save()){
    			
    		return response()->json(array('message' => $this->getNonErrorMessage(-1, array()), 'user' => $user) , 200 );
    	}
    	 
    	return response()->json(array('message' => $this->getErrorMessage(4, array()), 'errors' => array()) , 200 );
    
    }
    
    /**
     * @type POST
     * @param $request,$id
     * @desc Update User input By User Id, Retreive User Information By User Id
     */
    public function UserRegistration(Request $request)
    {
    	$_regtype = $request->input('_regtype');
    	 
    	if ($request->isMethod('post') && strtolower($_regtype) == strtolower('Validate'))
    
    		return $this->ValidateRegistUser($request);
    	 
    	elseif ($request->isMethod('post') && strtolower($_regtype) == strtolower('Save'))
    	 
    	return $this->RegistUser($request);
    	 
    	else
    
    		return response()->json(array('message' => $this->getNonErrorMessage(4, array()), 'errors' => array()) , 400 );
    }
    
    /**
     * Get Error Messages
     * @param $i, $param
     * @desc Return Error Messages
     */
    protected function getErrorMessage($i, $param){
    	 
    	switch ($i) {
    
    		case 0:
    		  
    			return sprintf(trans('validation.custom.editvaluserstatus.status'));
    		  
    			break;
    
    		case 1:
    		  
    			return sprintf(trans('validation.custom.editgetuserstatus.autherror'));
    
    			break;
    
    		case 2:
    
    			return sprintf(trans('validation.custom.editgetuserstatus.nouser'));
    
    			break;
    
    		case 3:
    
    			return sprintf("Could not edit user information.");
    
    			break;
    
    		case 4:
    
    			return sprintf(trans('validation.custom.regsavuserstatus.status'));
    
    			break;
    
    		case 5:
    
    			return sprintf(trans('validation.custom.regvaluserstatus.status'));
    
    			break;
    
    		default:
    
    			echo sprintf("Unknown Error!");
    	}
    }
    
    /**
     * Get Messages
     * @param $i, $param
     * @desc Return Non-Error Messages
     */
    protected function getNonErrorMessage($i, $param){
    
    	switch ($i) {
    
    		case 0:
    
    			return sprintf('Successfully Updated!');
    
    			break;
    			 
    		case 1:
    			 
    			return sprintf('Valid');
    			 
    			break;
    
    		default:
    
    			return sprintf("Success!");
    	}
    }
    
    /**
     * Validate Fields
     * @param $request
     * @desc Return Non-Error Messages
     */
    protected function ValidateFields($request, $type, $id = 0){
    
    	if($type == 0){
    
    		$type = 'required|email|max:255|unique:users';
    		 
    		$pass = 'min:5|max:60|required';
    
    		$pass_confirm = 'required|same:password';
    
    	}else{
    
    		$type = 'required|email|max:255|unique:users,email,'.$id;
    		 
    		if(empty($request->input('password'))
    				&& empty($request->input('password_confirm'))){
    			$pass = '';
    
    			$pass_confirm = '';
    
    		}else{
    			 
    			$pass = 'min:5|max:60|required';
    			 
    			$pass_confirm = 'required|same:password';
    		}
    	}
    	 
    
    	return Validator::make($request->all(), [
    
    			'name'       		=> 'required|max:255',
    
    			'email'      		=> $type,
    
    			'email_confirm'     => 'required|same:email',
    
    			'password' 			=> $pass,
    
    			'password_confirm'  => $pass_confirm
    
    			]);
    
    }

    /**
     * Get Users Ticket Functions
     * @param $request
     * @by Rei
     */
    public function getTickets($id) {
        if( $id != $this->login_id && $this->login_role != 'admin') {
            return response()->json(['message'=>trans('custom.error_auth')],401);
        }
        $data = \App\UserTicket::where('user_id',$id)->with('ticket')->get();
        if($data->count()) {
            return $this->makeUserTicket($data);
        } else {
            return response()->json(['message'=>trans('custom.record_not_found',['name'=>'ticket'])],204);
        }
    }

    public function getTicketsShow($id,$user_ticket_id) {
        if($id != $this->login_id && $this->login_role != 'admin') {
            return response()->json(['message'=>trans('custom.error_auth')],401);
        }
        $data = \App\UserTicket::where('user_id',$id)->where('id',$user_ticket_id)->with('ticket')->with('split_ticket')->get();
        if($data->count()) {
            return $this->makeUserTicketDetail($data);
        } else {
            return response()->json(['message'=>trans('custom.record_not_found',['name'=>'ticket'])],204);
        }
    }

    protected function makeUserTicket($arr) {
        $temp = array();
        foreach($arr as $key => $value) {
            $temp['user_tickets'][] = array(
                'id'            => $value->id,
                'name'          => $value->ticket->name,
                'description'   => $value->ticket->description,
                'type'          => $value->ticket->type,
                'adult_num'     => $value->adult_num,
                'child_num'     => $value->child_num,
                'purchase_date' => $value->purchase_date,
                'started_date'  => $value->started_date,
                'expired_date'  => $value->expired_date
            );
        }
        return $temp;
    }

    protected function makeUserTicketDetail($arr) {
        $temp = array();
        foreach($arr as $key => $value) {
            $temp['user_tickets'][] = array(
                'id'            => $value->id,
                'name'          => $value->ticket->name,
                'description'   => $value->ticket->description,
                'type'          => $value->ticket->type,
                'adult_num'     => $value->adult_num,
                'child_num'     => $value->child_num,
                'purchase_date' => $value->purchase_date,
                'started_date'  => $value->started_date,
                'expired_date'  => $value->expired_date,
                'split_tickets' => $value->split_ticket
            );
        }
        return $temp;
    }
    public function postTicketsPurchase(Request $request,$id) {
        if($id != $this->login_id && $this->login_role != 'admin') {
            return response()->json(['message'=>trans('custom.error_auth')],401);
        }
        $validator = \Validator::make($request->all(), [
            'adult_num' => 'required|numeric',
            'child_num' => 'required|numeric',
            'ticket_id' => 'required'
        ]);
        if($validator->fails()) {
            return response()->json(['message'  => trans('custom.fail_to',['name'=>'purchase ticket']),'errors' => $validator->errors()],422);
        }
        \DB::beginTransaction();

        $adult_total = $child_total = 0;
        $ticket         = \App\Ticket::find($request->input('ticket_id'));
        $adult_total    = $request->input('adult_num') * $ticket->first()->adult_price;
        $child_total    = $request->input('child_num') * $ticket->first()->child_price;

        $user_ticket = \App\UserTicket::create([
            'user_id'       => $this->login_id,
            'ticket_id'     => $request->input('ticket_id'),
            'adult_num'     => $request->input('adult_num'),
            'child_num'     => $request->input('child_num'),
            'purchase_date' => \Carbon\Carbon::now(),
            'valid'         => true
        ]);

        $purchase_history  = \App\PurchaseHistory::create([
            'ticket_id'         => $request->input('ticket_id'),
            'user_ticket_id'    => $user_ticket->id,
            'adult_num'         => $request->input('adult_num'),
            'child_num'         => $request->input('child_num'),
            'amount'            => $adult_total + $child_total,
            'purchase_date'     => \Carbon\Carbon::now(),
            'valid'             => true
        ]);

        if(!$user_ticket || !$purchase_history) {
            \DB::rollBack();
            return response()->json(['message'  => trans('custom.fail_to',['name'=>'purchase ticket'])],400);
        } else {
            \DB::commit();
            return response()->json(['result'  => trans('custom.success')],200);
        }

    }

    public function postTicketsSplit(Request $request,$id,$user_ticket_id) {
        if($id != $this->login_id && $this->login_role != 'admin') {
            return response()->json(['message'=>trans('custom.error_auth')],401);
        }
        $validator = \Validator::make($request->all(), [
            'adult_num' => 'required|numeric|min:1',
            'child_num' => 'required|numeric|min:1',
        ]);
        if($validator->fails()) {
            return response()->json(['message'  => trans('custom.fail_to',['name'=>'ticket split']),'errors' => $validator->errors()],422);
        }
        $user_ticket = \App\UserTicket::where('id',$user_ticket_id)->get();
        $receive_key = str_random(25);
        if($user_ticket->count()) {
            if( $request->input('adult_num')>$user_ticket->first()->adult_num || $request->input('child_num')>$user_ticket->first()->child_num ) {
                return response()->json(['message'  => trans('custom.fail_to',['name'=>'ticket split'])],400);
            }
            \DB::beginTransaction();
            $user_ticket->first()->adult_num = $user_ticket->first()->adult_num - $request->input('adult_num');
            $user_ticket->first()->child_num = $user_ticket->first()->child_num - $request->input('child_num');
            $user_ticket->first()->save();

            $split_ticket = \App\SplitTicket::create([
                'receive_key'       => $receive_key,
                'user_ticket_id'    => $user_ticket->first()->id,
                //'received_user_id'  => $this->login_id,
                //'received_date'     => \Carbon\Carbon::now(),
                'adult_num'         => $request->input('adult_num'),
                'child_num'         => $request->input('child_num'),
                'valid'             => true
            ]);
           if(!$split_ticket) {
                \DB::rollBack();
                return response()->json(['message'  => trans('custom.fail_to',['name'=>'ticket split'])],400);
            } else {
                \DB::commit();
                return response()->json(['result'  => trans('custom.success')],200);
            }
           return response()->json([
                'split_ticket' => array(
                    'id'            => $split_ticket->id,
                    'receive_key'   => $split_ticket->receive_key,
                    'adult_num'     => $split_ticket->adult_num,
                    'child_num'     => $split_ticket->child_num,
                    'splited_date'  => \Carbon\Carbon::now()
                )
            ]);
        } else {
            return response()->json(['message'=>trans('custom.record_not_found',['name'=>'ticket'])],204);
        }
    }

    public function postTicketsReceive(Request $request,$id) {
        if($id != $this->login_id) {
            return response()->json(['message'=>trans('custom.error_auth')],401);
        }
        $validator = \Validator::make($request->all(), [
            'receive_key' => 'required',
        ]);
        if($validator->fails()) {
            return response()->json(['errors' => $validator->errors()],422);
        }
        $check_receive_key = \App\SplitTicket::where('receive_key', $request->input('receive_key'))->get();
        if($check_receive_key->count()) {
            $get_user_ticket   = \App\UserTicket::where('id',$check_receive_key->first()->user_ticket_id)->get();
            \DB::beginTransaction();
            $check_receive_key->first()->received_user_id   = $id;
            $check_receive_key->first()->received_date      = \Carbon\Carbon::now();
            $check_receive_key->first()->save();

            $user_ticket = \App\UserTicket::create([
                'user_id'       => $this->login_id,
                'ticket_id'     => $get_user_ticket->first()->ticket_id,
                'adult_num'     => $check_receive_key->first()->adult_num,
                'child_num'     => $check_receive_key->first()->child_num,
                'purchase_date' => \Carbon\Carbon::now(),
                'valid'         => true
            ]);
            if(!$user_ticket) {
                \DB::rollBack();
                return response()->json(['message'  => trans('custom.fail_to',['name'=>'receive ticket'])],400);
            } else {
                \DB::commit();
                return response()->json(['result'  => trans('custom.success')],200);
            }
        } else {
            return response()->json(['message'=>trans('custom.record_not_found',['name'=>'receive key'])],204);
        }
    }

    public function postStartTicket($id,$user_ticket_id) {
        if($id != $this->login_id && $this->login_role != 'admin') {
            return response()->json(['message'=>trans('custom.error_auth')],401);
        }
        $user_ticket = \App\UserTicket::where('id',$user_ticket_id)->with('ticket')->get();
        if($user_ticket->count()) {
            $user_ticket    = $user_ticket->first();
            if($user_ticket->ticket->effect_days && !$user_ticket->ticket->effect_time) { //day
                $user_ticket->started_date = \Carbon\Carbon::now();
                $user_ticket->expired_date = \Carbon\Carbon::now()->addDays($user_ticket->ticket->effect_days);
                $user_ticket->save();
                return response()->json($this->makeUserTicket(array($user_ticket)),200);
            }
            else if($user_ticket->ticket->effect_time && !$user_ticket->ticket->effect_days) { //time
                $user_ticket->started_date = \Carbon\Carbon::now();
                $user_ticket->expired_date = \Carbon\Carbon::now()->addHours($user_ticket->ticket->effect_time);
                $user_ticket->save();
                return response()->json($this->makeUserTicket(array($user_ticket)),200);

            } else {
                return response()->json(['message'=>trans('custom.fail_to',['name'=>'start ticket'])],400);
            }
        } else {
            return response()->json(['message'=>trans('custom.record_not_found',['name'=>'ticket'])],204);
        }
    }

}
