<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Ticket;

class TicketsController extends Controller
{

    /** 
     * @var Item
     */
    protected $ticket;

    /** 
     * @param Ticket $user
     */
    public function __construct(Ticket $ticket)
    {   
        $this->ticket = $ticket;
    }
    //
    public function getIndex()
    {   
        $tickets = $this->ticket->getGroupedByType();
        return response()->json(array(
           'tickets' => $tickets),
            200
        );
    }

    public function getShow($id)
    {   
        $ticket = $this->ticket->where('valid', true)
            ->where('id', $id)
            ->first(['id', 'name', 'description', 'adult_price', 'child_price',
                'type','effect_time','effect_days']);
        if(empty($ticket)){
            return response()->json("",204);
        }
        return response()->json(array(
           'ticket' => $ticket->toArray()),
            200
        );
    }
}
