<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class SplitTicketsController extends Controller
{
    public function getShow($receive_key) {
    	$data = \App\SplitTicket::where('receive_key',$receive_key)->with('user_ticket.ticket')->get();
    	if($data->count()) {
    		return $this->makeSplitTicket($data);
    	} else {
    		return response()->json(['message'=>trans('custom.record_not_found',['name'=>'receive key'])],204);
    	}
    }
    protected function makeSplitTicket($arr) {
        $temp = array();
        foreach($arr as $key => $value) {
            $temp['split_ticket'] = array(
                'id'            => $value->id,
                'receive_key'   => $value->receive_key,
                'name'          => $value->user_ticket->ticket->name,
                'type'          => $value->user_ticket->ticket->type,
                'adult_num'     => $value->adult_num,
                'child_num'     => $value->child_num,
                'purchase_date' => $value->user_ticket->purchase_date
            );
        }
        return $temp;
    }
}
