<?php 
namespace App\Http\Controllers\Auth;
use App\User;
use App\RefreshToken;
use App\AccessToken;

use App\Http\Controllers\Controller;
use Illuminate\Contracts\Auth\Guard;
use App\Http\Requests\Auth\LoginRequest;
use App\Http\Requests\Auth\RegisterRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Validator;

class AuthController extends Controller {
    protected $user; 
    protected $auth;
    public function __construct(Guard $auth, User $user)
    {
        $this->user         = $user; 
        $this->auth         = $auth;
        $this->current_date = date('Y-m-d H:i:s');
    }
    /**
     * Handle a registration request for the application.
     *
     * @param  RegisterRequest  $request
     * @return Response
     */
    public function postRefresh(Request $request) {
        $refresh_token_expire_date  = Auth::guard('api')->user()->refresh_token->expired_date;
        if( strtotime($refresh_token_expire_date)<strtotime($this->current_date) ) {
            return response()->json(['message'  => trans('custom.fail_to',['name'=>'refresh token'])],400);
        } else {
            $refresh_token = $this->saveTokens('api',$request->all());  //save to db
            return response()->json([ //response from db
                'access_token'  =>  $refresh_token['api_token'],
                'expired_date'  =>  $refresh_token['expired_date'],
            ],200);
        }
    }
    /**
     * Handle a login request to the application.
     *
     * @param  LoginRequest  $request
     * @return Response
     */
    public function postLogin(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required',
        ]);
        if($validator->fails()) {
            return response()->json(['message'=>trans('custom.fail_to',['name'=>'login']),'errors'=>$validator->errors()],422);
        }
        $credentials = ['email' => $request->input('email'), 'password' => $request->input('password')];

        if (Auth::guard('web')->attempt($credentials))
        {
            $login_token = $this->saveTokens('web',$request->all()); //save to db
            return response()->json([   // response from db
                'access_token'  =>  $login_token['api_token'],
                'expired_date'  =>  $login_token['expired_date'],
                'refresh_token' =>  $login_token['refresh_token'],
                'user'          => array('id'=> $this->guardData('web')['id'], 'name' => $this->guardData('web')['name']),
            ],200);
        }
 
        return response()->json(['message'  => trans('custom.fail_to',['name'=>'login']),'errors' => $validator->errors()],422);
    }
 
    protected function saveTokens($guard=null, $data=null) {
        $api_client_id = \App\ApiClient::where('secret',$data['api_secret'])->where('name',$data['api_client_name'])->get();
        \DB::beginTransaction();
        $new_refresh_token      = RefreshToken::create([
                                   'refresh_token'  => $this->user->generateToken()['refresh_token'],
                                   'expired_date' => $this->user->generateToken()['expired_date'],
                                   'valid' => true,
                                ]);

        $new_access_token       = AccessToken::create([
                                'api_token'      => $this->user->generateToken()['api_token'],
                                'expired_date'      => $this->user->generateToken()['expired_date'],
                                'refresh_token_id'  => $new_refresh_token->id,
                                'valid'             => true,
                                'user_id'           => $this->guardData($guard)['id'],
                                'api_client_id'     => (isset($api_client_id->first()->id))?$api_client_id->first()->id: null,
                           ]);
        if(!$new_refresh_token || !$new_access_token) {
            \DB::rollBack();
            return response()->json(['message'  => trans('custom.error_saving')],422);
        } else {
            \DB::commit();
        }
        return array(
            'api_token'  =>  $new_access_token->api_token,
            'expired_date'  =>  $new_access_token->expired_date,
            'refresh_token_id' => $new_refresh_token->id,
            'refresh_token' => $new_refresh_token->refresh_token,
        );
    }
    public function guardData($guard=null) {
        if($guard=="api") {
            return array('id'=>Auth::guard($guard)->user()->user_data->id,'email'=>Auth::guard($guard)->user()->user_data->email );
        } else if($guard=="web") {
            return array('id'=>Auth::guard($guard)->user()->id,'name' => Auth::guard($guard)->user()->name,'email'=>Auth::guard($guard)->user()->email );
        }
    }
}