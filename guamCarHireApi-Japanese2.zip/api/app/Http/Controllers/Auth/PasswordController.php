<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ResetsPasswords;
use Illuminate\Http\Request;

class PasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset requests
    | and uses a simple trait to include this behavior. You're free to
    | explore this trait and override any methods you wish to tweak.
    |
    */

    use ResetsPasswords;

    /**
     * Create a new password controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }
    
    public function postReissuePassword(Request $request) {
    	$validator = \Validator::make($request->all(),[
    			'email' => 'required|email'
    			]);
    	if($validator->fails()) {
    		 
    		return response()->json(['message'=>trans('custom.fail_to',['name'=>'reissue password']),'errors'=>$validator->errors()],200);
    	} else {
    		$user = \App\User::where('email',$request->input('email'));
    		if($user->count()) {
    			$user           = $user->first();
    			$new_password   = str_random(8);
    
    			$user->password = bcrypt($new_password);
    			if($user->save()) {
    				\Mail::send('email.auth.forgot', array('link'=>env('API_URL'),'username' => $user->username, 'password' => $new_password), function($message) use($user) {
    					$message->from(env('MAIL_USERNAME'), 'Account Recovery');
    					$message->to($user->email,$user->name)->subject('New Password Request');
    				});
    				return response()->json(['result'=>trans('custom.success')],200);
    			}
    		} else {
    			return response()->json(['message'=>trans('custom.fail_to',['name'=>'reissue password']),'errors'=>array('email' => trans('custom.record_not_registered', ['name' => 'e-mail']) )],200);
    		}
    	}
    	return response()->json(['message'=>trans('custom.fail_to',['name'=>'reissue password'])],200);
    }
}
