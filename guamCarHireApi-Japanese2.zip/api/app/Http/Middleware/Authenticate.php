<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Http\Middleware\BeforeMiddleware;

class Authenticate
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
    {
        if (Auth::guard($guard)->guest()) {
            return response()->json(['message'  => "Unauthorized."],401);
        } else {
            if (Auth::check())
            {
                if( strtotime(Auth::guard('api')->user()->expired_date)<strtotime(date('Y-m-d H:i:s')) ) {
                    return response()->json(['message'  => trans('custom.token_expired')],401);
                }
                $middleware = new BeforeMiddleware();
                if($middleware->api_client($request)->id != Auth::guard('api')->user()->api_client_id) {
                    return response()->json(['message'  => "Authentication Error."],401);
                }
            }
        }
        $lang = $request->header('Accept-Language');
        \App::setLocale($lang);
        return $next($request);
    }
}
