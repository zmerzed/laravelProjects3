<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SplitTicket extends Model
{
    protected $table = 'split_tickets';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'receive_key', 'user_ticket_id', 'received_user_id', 'received_date', 'adult_num','child_num','valid'
    ];

    public function user_ticket() {
    	return $this->belongsTo('App\UserTicket','user_ticket_id');
    }
}
