<!DOCTYPE html>
<html lang="en">
<head>
	<script type="text/javascript">
		window.onload = function () {
		  window.print();
		  setTimeout(function(){window.close();}, 1);
		}
	</script>
</head>
    <body>
	    <?php echo e($date); ?> ID: GUEST<h1><?php echo e($pw); ?></h1>
<font size="1">Apply for weekly or monthly membership.<br />
Weekly only P<?php echo e($weekly_fee); ?>.<br />
Monthly only P<?php echo e($monthly_fee); ?>.<br /></font>
	</body>
</html>