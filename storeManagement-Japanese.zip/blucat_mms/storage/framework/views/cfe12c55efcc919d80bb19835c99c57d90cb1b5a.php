<table id="sample-table" class="table table-hover table-bordered tablesorter">
   <thead>
        <tr>
            <th style="width:20%">Time</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($actions as $action): ?>
        <tr>
            <td><?php echo e($action->created_at); ?></td>
            <td><?php echo e($action->message); ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>