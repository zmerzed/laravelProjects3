<form method="POST" action="/user/create-confirm">
    <?php echo csrf_field(); ?>

    <div>ID<input type="text" name="name" value="<?php echo e(old('name')); ?>"></div>
    <div>メールアドレス<input type="email" name="email" value="<?php echo e(old('email')); ?>"></div>
    <div>パスワード<input type="password" name="password"></div>
    <div>パスワード確認<input type="password" name="password_confirmation"></div>
    <div>住所<input type="text" name="address" value="<?php echo e(old('address')); ?>"></div>
    <div>電話番号<input type="text" name="tel" value="<?php echo e(old('tel')); ?>"></div>
    <div><button type="submit">登録</button></div>
</form>	
<?php foreach($errors->all() as $error): ?>
<?php echo e($error); ?>

<?php endforeach; ?>