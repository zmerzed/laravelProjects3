<?php $__env->startSection('title', 'IPPP MMS / Wifi'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('left-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section class="nav nav-page">
<div class="container">
    <div class="row">
        <div class="span7">
            <header class="page-header">
                <h3>Wifi<br/><small>Manage Wifi Password</small></h3>
            </header>
        </div>
        <div class="span9">
            <ul class="nav nav-pills">
                <li>
                    <button id="vtour-button" rel="tooltip" onclick="window.open('/wifi/print');" title="Print Wifi Password" data-placement="bottom">
                        <i class="icon-print icon-large"></i>
                    </button>
                </li>
                <li>
                    <button href="#updateModal" role="button" data-toggle="modal" id="vguide-button" rel="tooltip" title="Input Wifi Password" data-placement="bottom">
                        <i class="icon-cogs icon-large"></i>
                    </button>
                </li>
            </ul>
        </div>
    </div>
</div>
</section>
<section class="page container">
<div class="row">
    <div class="span16">
        <div class="box">
            <div class="box-header">
                <i class="icon-user"></i>
                <h5>Membership Search</h5>
            </div>
            <div class="box-content">
                <legend class="lead">
                    Member ID : 
                    <form class="form-inline" method="get" action="/wifi">
                        <div class="input-prepend">
                            <span class="add-on"><i class="icon-barcode"></i></span>
                            <input name="mid" id="mid" class="span4" type="text" placeholder="Member ID" value="<?php echo e($mid); ?>">
                            <button type="submit" class="btn btn-primary">
                                <i class="icon-search"></i>
                                Search
                            </button>
                        </div>
                    </form>
                </legend>
                <?php if(count($member)>0): ?>
                <div class="box-content">
                    <div class="well well-small well-shadow span3">
                        <img src="<?php echo e(asset('images/member/'.$member->pic)); ?>" />
                    </div>
                    <div class="well well-small well-shadow span4">
                        <legend class="lead">EXPIRE</legend>
                        <div class="box-content">
                            <h2 style="text-align:center" class="alert-info"><?php echo e(!is_null($member->wifi_exp_date)?Carbon\Carbon::parse($member->wifi_exp_date)->format('Y/m/d'):"NULL"); ?></h2>
                            <a href="#renewModal" role="button" data-toggle="modal" class="btn btn-large btn-info">
                                <i class="btn-icon-only icon-repeat"> RENEW</i>
                            </a>
                            <?php if(!is_null($member->wifi_exp_date)): ?>
                            <a href="javascript:window.open('wifi/print/<?php echo e($mid); ?>');" role="button" data-toggle="modal" class="pull-right btn btn-large btn-info">
                                <i class="btn-icon-only icon-print"> PRINT</i>
                            </a>
                            <?php endif; ?>
                        </div>
					</div>
                    <?php echo $__env->make('member-info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('actions', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                    <?php echo $__env->make('modals.wifi.renew-modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php else: ?>
                    <?php if(strlen($mid)>0): ?>
                        Not found
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
</section>
<?php echo $__env->make('modals.wifi.update-modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script src="/js/bootstrap/bootstrap-transition.js" type="text/javascript" ></script>
<script src="/js/bootstrap/bootstrap-modal.js" type="text/javascript" ></script>
<script src="/js/bootstrap/bootstrap-tooltip.js" type="text/javascript" ></script>
<script type="text/javascript">
    $('#updateModal').on('shown', function(){
        $('#wifiPass').focus();  
    });
    $("[rel=tooltip]").tooltip();
    $('#mid').focus();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>