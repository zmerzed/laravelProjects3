<?php $__env->startSection('title', 'IPPP MMS / Wifi'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('left-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<style>
    #gallery .thumbnail{
        width:200px;
        height: 150px;
        float:right;
    }
    #gallery .thumbnail img{
        width:200px;
        height: 150px;
    }
    #edit_gallery .thumbnail{
        width:200px;
        height: 150px;
        float:right;
    }
    #edit_gallery .thumbnail img{
        width:200px;
        height: 150px;
    }
</style>
<section class="nav nav-page">
    <div class="container">
        <div class="row">
            <div class="span7">
                <header class="page-header">
                    <h3>Membership<br/><small>Manage Membership</small></h3>
                </header>
            </div>
            <div class="page-nav-options">
                <div class="span9">
                    <ul class="nav nav-pills">
                        <li>
                            <a href="#addmemberModal" data-toggle="modal" title="Add Membership"><i class="icon-plus icon-large"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="page container">
    <div class="row">
        <div class="span16">
            <div class="box">
            <div class="box-header">
                <i class="icon-user"></i>
                <h5>
                    Membership
                </h5>
            </div>
            <div class="box-content">
                <legend class="lead">
                    Member ID : 
                    <form class="form-inline" method="GET" action="/membership">
                        <div class="input-prepend">
                            <span class="add-on"><i class="icon-barcode"></i></span>
                            <input id="mid" name="mid" value="<?php echo e($mid); ?>" class="span4" type="text" placeholder="Member ID">
                        </div>
                        <div class="input-prepend">
                            <span class="add-on"><i class="icon-user"></i></span>
                            <input id="firstname" name="firstname" value="<?php echo e($firstname); ?>" class="span4" type="text" placeholder="First Name">
                        </div>
                        <div class="input-prepend">
                            <span class="add-on"><i class="icon-user"></i></span>
                            <input id="lastname" name="lastname" value="<?php echo e($lastname); ?>" class="span4" type="text" placeholder="Last Name">
                        </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">
                            <i class="icon-search"></i>
                            Search
                        </button>
                    </div>
                    </form>
                </legend>
            </div>
            
            <div class="box-content box-table">
            <?php if(count($members)>0): ?>
            <table id="sample-table" class="table table-hover table-bordered tablesorter">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Expiration</th>
                        <th class="td-actions"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($members as $member): ?>
                    <tr>
                        <td><?php echo e($member->id); ?></td>
                        <td><?php echo e($member->first_name); ?></td>
                        <td><?php echo e($member->last_name); ?></td>
                        <td><?php echo e($member->wifi_exp_date); ?></td>
                        <td class="td-actions">
                            <a class="btn btn-small btn-info" data-toggle="modal" data-target="#edit-member-modal" id="<?php echo e($member->id); ?>">
                                <i class="btn-icon-only icon-cogs"></i>
                            </a>

                            <a class="btn btn-small btn-danger" data-toggle="modal" data-target="#delete-member-modal" id="<?php echo e($member->id); ?>">
                                <i class="btn-icon-only icon-remove"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
            </div>
            
        </div>
    </div>
    <?php echo $__env->make('modals.member.add-modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('modals.member.view-modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('modals.member.delete-modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('modals.member.error-modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</section>

<script src="/js/bootstrap/bootstrap-transition.js" type="text/javascript" ></script>
<script src="/js/bootstrap/bootstrap-modal.js" type="text/javascript" ></script>
<script src="/js/bootstrap/bootstrap-tooltip.js" type="text/javascript" ></script>
<script type="text/javascript">$(window).load(function(){MMS.membership()})</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>