<div class="well well-small well-shadow span6">
    <legend class="lead">Member Info&nbsp;<span class="alert-info"><?php echo e(isset(config('define.ranking')[$member->ranking])?config('define.ranking')[$member->ranking]['name']:false); ?></span></legend>
    <div class="box-content">
        <span><i class="btn-icon-only icon-barcode"></i> : <span><code><?php echo e($member->id); ?></code><br />
	    <span><i class="btn-icon-only icon-user"></i> : <span><code><?php echo e($member->first_name); ?>&nbsp;<?php echo e($member->last_name); ?></code><br />
	    <span><i class="btn-icon-only icon-phone"></i> : <span><code><?php echo e($member->contact_number); ?></code><br />
	    <span><i class="btn-icon-only icon-envelope"></i> : <span><code><?php echo e($member->mail_address); ?></code><br />
	    <span><i class="btn-icon-only icon-money"></i> : <span><code><?php echo e($member->points); ?></code><br />
    </div>
</div>
