<?php
namespace App\Exceptions;

class ValidationException extends BaseException {
}