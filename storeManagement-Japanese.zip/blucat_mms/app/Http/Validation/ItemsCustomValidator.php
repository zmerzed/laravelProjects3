<?php
namespace App\Http\Validation;

class ItemsCustomValidatorExtended extends Validator {

}