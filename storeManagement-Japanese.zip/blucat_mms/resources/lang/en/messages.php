<?php
    /* ERROR MESSAGES */
    return [
        'system_error' => 'something system error occurred.',
        'units' => [
            'create'=>'Unit was successfully created',
            'update'=>'Unit was successfully updated'
        ],
        'menus' => [
            'create'=>'Menu was successfully created',
            'update'=>'Menu was successfully updated'
        ]
    ];
