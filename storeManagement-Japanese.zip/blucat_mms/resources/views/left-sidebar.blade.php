<div class="body-nav body-nav-vertical body-nav-fixed">
    <div class="container">
        <ul>
            <li>
                <a href="/">
                    <i class="icon-user icon-large"></i> Loyality
                </a>
            </li>
            <li>
                <a href="/wifi">
                    <i class="icon-signal icon-large"></i> Wifi
                </a>
            </li>
            <li>
                <a href="/membership">
                    <i class="icon-cogs icon-large"></i> Settings
                </a>
            </li>
        </ul>
    </div>
</div>