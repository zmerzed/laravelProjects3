<section>
  <footer>
    <div class="row">{!! trans('global.copyright') !!}</div>
  </footer>
</section>