<!DOCTYPE html>
<html lang="en">
<head>
    <script type="text/javascript">
        window.onload = function () {
            window.print();
            setTimeout(function(){window.close();}, 1);
        }
    </script>
</head>
<body>
{{$date}} ID:{{$mid}} &nbsp;
<br/>
{{$name}}<h1>{{$pw}}</h1>
<font size="1">
    No sharing is allowed.<br />
</font>
</body>
</html>